import java.lang.*;
import java.util.*;

public class Flight extends Fare {

  public String number;
  public Itinerary itinerary;
  public DepartureDate departureDate;
  public String pilotName;

  public Flight() {
  }

  public Flight(String number, Itinerary itinerary, DepartureDate departureDate, String pilotName, int price) {
    super(price);
    this.number = number;
    this.itinerary = itinerary;
    this.departureDate = departureDate;
    this.pilotName = pilotName;
  }

  Itinerary getItinerary() {
    return this.itinerary;
  }

  public String getNumber() {
    return number;
  }

  public void setNumber(String number) {
    this.number = number;
  }

  public void setItinerary(Itinerary itinerary) {
    this.itinerary = itinerary;
  }

  public DepartureDate getDepartureDate() {
    return departureDate;
  }

  public void setDepartureDate(DepartureDate departureDate) {
    this.departureDate = departureDate;
  }

  public String getPilotName() {
    return pilotName;
  }

  public void setPilotName(String pilotName) {
    this.pilotName = pilotName;
  }
}
