import java.lang.*;
import java.io.*;
import java.sql.Time;
import java.util.*;

public class Passenger extends Flight {

  public String identity;
  public ArrayList<Flight> arrayflights;
  public int flightCost;

  public Passenger() {
    this.arrayflights = new ArrayList<Flight>();
    this.flightCost = 0;
  }

  public Passenger(String identity) {
    this.arrayflights = new ArrayList<Flight>();
    this.identity = identity;
    this.flightCost = 0;
  }

  public int getFlightCost() {
    return flightCost;
  }

  public void setFlightCost(int flightCost) {
    this.flightCost = flightCost;
  }

  public String getIdentity() {
    return identity;
  }

  public void setIdentity(String identity) {
    this.identity = identity;
  }

  public void bookFlight(Flight flight) {
    this.arrayflights.add(flight);
  }

  public void cancelFlight(Flight flight) {
    for (int index = 0; index < this.arrayflights.size(); index++) {
      Flight f = this.arrayflights.get(index);
      if (flight.number == f.getNumber()) {
          this.arrayflights.remove(index);
          break;
        }
    }
  }

  public void listFlights() {
    System.out.println("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n");
    System.out.printf("PASSENGE NAME : %s\n",this.getIdentity());
    for (int index = 0; index < this.arrayflights.size(); index++) {
      Flight f = this.arrayflights.get(index);
      System.out.printf("FLIGHT NUMBER : %s\n",f.getNumber());
      System.out.printf("START LOCATION : %s\n",f.getItinerary().getStartPoint());
      System.out.printf("END LOCATION : %s\n",f.getItinerary().getEndPoint());
      System.out.printf("DEPARTURE DATE : %s\n",f.getDepartureDate().getDate());
      System.out.printf("DEPARTURE TIME : %s\n",f.getDepartureDate().getTime());
      System.out.printf("PILOT NAME : %s\n",f.getPilotName());
    }
  }

}
