import java.lang.*;

public class Itinerary {

  public String startPoint;
  public String endPoint;

  public Itinerary() {

  }

  public Itinerary(String startPoint, String endPoint) {
    this.startPoint = startPoint;
    this.endPoint = endPoint;
  }

  public String getStartPoint() {
    return startPoint;
  }

  public void setStartPoint(String startPoint) {
    this.startPoint = startPoint;
  }

  public String getEndPoint() {
    return endPoint;
  }

  public void setEndPoint(String endPoint) {
    this.endPoint = endPoint;
  }
}
