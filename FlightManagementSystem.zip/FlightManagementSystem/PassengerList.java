import java.lang.*;

public class PassengerList extends Seat {

  public ArrayList<Seat> listOfPassengers;

  public PassengerList() {

  }

  public PassengerList(ArrayList<Seat> listOfPassengers) {
    this.listOfPassengers = listOfPassengers;
  }

  public void add(Seat s) {
    this.listOfPassengers.add(s);
  }

  public void remove(int seatNumber) {
    for (int index = 0; index < this.listOfPassengers.size(); index++) {
      Seat mySeat = this.listOfPassengers.get(index);
      if (mySeat.number == seatNumber) {
        this.listOfPassengers.remove(index);
        break;
      }
    }
  }

  public ArrayList<Seat> getListOfPassengers() {
    return listOfPassengers;
  }

  public void setListOfPassengers(ArrayList<Seat> listOfPassengers) {
    this.listOfPassengers = listOfPassengers;
  }
}
